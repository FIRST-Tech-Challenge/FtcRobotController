package org.firstinspires.ftc.teamcode.src.Utills;

public interface Executable <ReturnType> {

    ReturnType call();

}
