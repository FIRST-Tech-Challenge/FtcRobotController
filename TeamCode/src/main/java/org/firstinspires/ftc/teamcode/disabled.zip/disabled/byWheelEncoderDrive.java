package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
@Autonomous(name="byWheelEncoderDriveTest",group="chrisBot")
@Disabled

public class byWheelEncoderDrive extends LinearOpMode {
    chrisBot robot = new chrisBot();
    @Override
    public void runOpMode() throws InterruptedException {
        robot.init(hardwareMap, telemetry);
        waitForStart();
        robot.byWheelEncoderDrive(6,0,6,0);
    }

}
