package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous(group="chrisBot", name="actualAutonV3")
@Disabled

public class actualAutonV3 extends LinearOpMode {

    chrisBot robot = new chrisBot();

    boolean debugWait = true;

    private ElapsedTime time = new ElapsedTime();

    @Override
    public void runOpMode() throws InterruptedException {

        robot.init(hardwareMap, telemetry);

        waitForStart();

        telemetry.clear();
        robot.breakTelemetry();
        telemetry.addLine("Started match");
        telemetry.update();
        time.reset();



        // Drive forward appropriate amount to be able to clearly see the rings

        telemetry.addLine("Driving forward...");
        telemetry.update();

        robot.encoderDrive(22);

        // Sense the number of rings using TensorFlow (demo code)
        // Activate TensorFlow Object Detection before we wait for the start command.
        // Do it here so that the Camera Stream window will have the TensorFlow annotations visible.

        if (robot.tfod != null) { robot.tfod.activate(); }
        boolean[] ringPositions;
        ringPositions = robot.detectRings();


        // Create boolean variables to store the amount of rings
        boolean oneRing = ringPositions[0];
        boolean fourRings = ringPositions[1];

        // Drive to first foam tile

        double inches = 34;

        if (oneRing) {
            inches += 30;
        }
        if (fourRings) {
            inches += 48;
        }

        telemetry.addLine("Driving " + inches + " inches...");
        telemetry.update();

        robot.encoderDrive(inches);

        robot.shootOn();

        if(!oneRing) {
            robot.byWheelEncoderDrive(0,25,0,25);
            pause(100);
            robot.byWheelEncoderDrive(0,-25,0,-25);
        }

        // leave goal

        telemetry.addLine("Moving right");
        telemetry.update();
        robot.wheelMecanumDrive(robot.calculateInches(24,-1*(inches - 24)), 0.7);


        // Line up with first target

        telemetry.addLine("Lining up with first Powershot target...");
        telemetry.update();

        robot.lineUp();
        ElapsedTime e = new ElapsedTime();
        for(int i = 0; i < 3; i++) {
            telemetry.addLine("Shoot!");
            telemetry.update();
            if(i == 0) {
                e.reset();
                while(e.milliseconds() < 200) {
                    robot.intakeOn();
                }
            }
            else {
                e.reset();
                while(e.milliseconds() < 500) {
                    robot.intakeOn();
                }
            }
            robot.intakeOff();
            if (i != 2) {
                telemetry.addLine("Moving over...");
                telemetry.update();
                robot.wheelMecanumDrive(robot.calculateInches(9,-2),0.7);
                robot.lineUp();
            }
            pause(300);
        }
        robot.shootOff();

        // Drive forward to go over white line

        telemetry.addLine("Moving over white line...");
        telemetry.update();

        robot.encoderDrive(0.5,8);

        telemetry.addData("Auton done, time elapsed (ms)",time.milliseconds());
        telemetry.update();

        // End auton

        sleep(60000);

    }

    private void pause(long ms) {
        if (debugWait) {
            sleep(ms);
        }
    }
}
