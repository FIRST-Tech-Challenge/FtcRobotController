package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

public class detectRings extends LinearOpMode {
    chrisBot robot = new chrisBot();
    boolean[] rings = {false, false};
    @Override
    public void runOpMode() throws InterruptedException {
        robot.init(hardwareMap, telemetry, true, true);
    }
}
