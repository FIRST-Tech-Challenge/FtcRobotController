package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
@TeleOp(name="servoTest",group="test")
@Disabled

public class servoTest extends LinearOpMode {

    DcMotorSimple sparkmini = null, sparkmini2 = null;

    @Override
    public void runOpMode() throws InterruptedException {

        sparkmini = hardwareMap.get(DcMotorSimple.class, "motorShooter1");
        sparkmini2 = hardwareMap.get(DcMotorSimple.class, "motorShooter2");
        sparkmini.setDirection(DcMotorSimple.Direction.FORWARD);
        sparkmini.setPower(0);
        sparkmini2.setPower(0);

        waitForStart();

        sparkmini.setPower(1);
        sparkmini2.setPower(1);

        while(true) {
            if(isStopRequested()) {
                sparkmini.setPower(1);
                sparkmini2.setPower(1);
                return;
            }

        }
    }
}
