package org.firstinspires.ftc.teamcode.Test;

import com.arcrobotics.ftclib.gamepad.GamepadEx;
import com.arcrobotics.ftclib.gamepad.GamepadKeys;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.Core.Logger;
import org.firstinspires.ftc.teamcode.Core.NewIntakeTransferHWmap;
import org.firstinspires.ftc.teamcode.Intake.IntakeFSM;
import org.firstinspires.ftc.teamcode.Launcher.Flywheel;
import org.firstinspires.ftc.teamcode.Launcher.LauncherServo;
import org.firstinspires.ftc.teamcode.Launcher.Turret;
import org.firstinspires.ftc.teamcode.Transfer.TransferFSM;
import org.firstinspires.ftc.teamcode.Transfer.TransferMotorFSM;

@TeleOp(group = "Launcher", name = "Full Launcher & Intake Transfer")
public class LauncherAndIntakeTransferIntegratedTest extends LinearOpMode {

    public NewIntakeTransferHWmap hwMap;
    public Turret turret;
    public Flywheel flywheel;
    public LauncherServo launcherServo;
    public IntakeFSM intakeFSM;
    public TransferFSM transferFSM;
    public TransferMotorFSM transferMotorFSM;
    private GamepadEx gamepad;
    Logger logger;


    @Override
    public void runOpMode() throws InterruptedException {

        hwMap = new NewIntakeTransferHWmap(hardwareMap);
        // launcherServo = new LauncherServo(telemetry, hwMap);
        flywheel = new Flywheel(hwMap, telemetry);
        // turret = new Turret(hwMap, telemetry);
        gamepad = new GamepadEx(gamepad1);
        logger = new Logger(telemetry);
        transferFSM = new TransferFSM(hwMap, telemetry, logger);
        intakeFSM = new IntakeFSM(hwMap, telemetry, logger, transferFSM);
        transferMotorFSM = new TransferMotorFSM(hwMap, telemetry);


        waitForStart();

        while (opModeIsActive()) {
            // launcherServo.updatePID();
            flywheel.update();
            // turret.updatePID();
            gamepad.readButtons();
            intakeFSM.updateState(gamepad.wasJustPressed(GamepadKeys.Button.Y), (gamepad.wasJustPressed(GamepadKeys.Button.DPAD_LEFT)));
            transferFSM.updateState(gamepad.wasJustPressed(GamepadKeys.Button.RIGHT_BUMPER), gamepad.wasJustPressed(GamepadKeys.Button.DPAD_LEFT));
            telemetry.update();
        }
    }
}
