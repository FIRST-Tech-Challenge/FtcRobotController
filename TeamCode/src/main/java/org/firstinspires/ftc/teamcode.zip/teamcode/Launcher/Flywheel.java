package org.firstinspires.ftc.teamcode.Launcher;

import com.acmerobotics.dashboard.config.Config;

import org.firstinspires.ftc.robotcore.external.Telemetry;
import org.firstinspires.ftc.teamcode.Core.MotorWrapper;
import org.firstinspires.ftc.teamcode.Core.NewIntakeTransferHWmap;

@Config
public class Flywheel {

    public static double vP = 3, vI = 0, vD = 0;
    public static double kS = 0, kV = 1.7, Ka = 0;
    public static double targetVelocity;
    private final MotorWrapper flywheelmotor;
    Telemetry telemetry;


    public Flywheel(NewIntakeTransferHWmap hwMap, Telemetry telemetry) {
        flywheelmotor = new MotorWrapper(hwMap.getFlywheelMotor(), true, 1, true);
        this.telemetry = telemetry;
    }

    public void update() {
        flywheelmotor.readVelocity();
        flywheelmotor.setVelocity(targetVelocity);
        flywheelmotor.setVelocityConstants(vP, vI, vD, kS, kV, Ka);
        telemetry.addData("Current Velocity", flywheelmotor.getVelocity());
        telemetry.addData("Target Velocity", targetVelocity);
    }
}
